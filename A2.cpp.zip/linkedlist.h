/* 
 * File:   linkedlist.h
 * Author: ESC
 *
 * Created on April 12, 2015, 4:26 PM
 */

#ifndef LINKEDLIST_H
#define	LINKEDLIST_H
typedef int listelemtype;
class linkedlist {
public:
    linkedlist();
    bool insert (const listelemtype &e );
    bool first ( listelemtype &e );
     bool next ( listelemtype &e );
      bool find ( listelemtype e );
      void del (const listelemtype &e);
private:struct  node;
typedef node* link;
struct node{
    listelemtype elem;
    link next;
   
};
link head,current,tail;
};

#endif	/* LINKEDLIST_H */

