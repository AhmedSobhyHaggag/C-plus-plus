/* 
 * File:   main.cpp
 * Author: ESC
 *
 * Created on April 12, 2015, 2:44 PM
 */
#include <string.h>
#include <cstdio>
#include <sstream>
#include <cstdlib>
#include "linkedlist.h"
#include "inorderlinkedlist.h"
#include <math.h>
#include <iostream>
using namespace std;

/*
 * 
 */
bool checkint1(int argc,char**argv)
{   

   for(int i=0;i<=strlen(argv[1])-1;i++)
{
  if(!isdigit(argv[1][i])) 
  {cout<<"Invalid seqNumBits";return 0;}
}
return 1;
}
bool checkint2(int argc,char**argv,int maxid)
{ 
    for(int i=0;i<=strlen(argv[2])-1;i++)
{
  if(!isdigit((argv[2][i]))) 
  {cout<<"Invalid initSeq";return 0;}
}
  if(atoi(argv[2])>maxid) 
  {cout<<"Invalid initSeq";return 0;}
return 1;
}
bool checkrest(int argc,char **argv,int maxid)
{
    for(int i=2;i<=argc-1;i++)
        {
          if((atoi(argv[i])>maxid))
          {cout<<"Invaid packet ID";  return 0;}
    }  
     for(int i=2;i<=argc-1;i++)
        {
         for(int j=0;j<=strlen(argv[i])-1;j++)
          if(!isdigit(argv[i][j]))
          {cout<<"Invalid packet  ID"; return 0;}
    }  
    
    return 1;
}

bool window(int id, int E,int maxid,int windowsize)
{int l,v,k;
l=E+windowsize-1;
if(l<=maxid){if(E<id&&id<=l) {
  return true;}
else {return false; }}
else if (l>maxid){v=maxid-E+1;k=windowsize-v;
if((E<id&&id<=maxid)||(0<=id&&id<=k)) return true;
else return false;}
else return false;  
}
 void ret(linkedlist t)
 {bool flag;int x;
 flag=t.first(x);
 while(flag)
 {
   cout<<x<<" ";
   flag=t.next(x);
 }
 }
 void reti(int argc,int E,int maxid,inorderlinkedlist t)
 {             
   bool flag;int x;
     E++;
              if(E>maxid)
              {{E--;
              E=E%maxid;}
              }
     for(int i=0;i<argc-1;i++)
     {
  if(t.find(E))  {cout<<E<<" "; t.del(E);}
               E++;
              if(E>maxid)
              {{E--;
              E=E%maxid;}
              }}
 }
 void checkw(int &E,linkedlist &R,inorderlinkedlist &w,int maxid)
 {  int l; bool flag;
        flag=w.first(l);
        while(flag)
        { if(l==E) {R.insert(l); w.del(l);
           E++;
           if(E>maxid)
           {E--;E=E%maxid;}
            }
          flag=w.next(l);}
 return;}
int main(int argc,char**argv)
{ 
    if(argc<3) { if(!checkint1(argc,argv)) return 0;
    else{ cout<<"Invalid initSeq";return 0;}}
    linkedlist R,D;
   inorderlinkedlist w;
    int E=0,windowsize=0,maxid=0;
     E=atoi(argv[2]);
     maxid=pow(2,atoi(argv[1]))-1;
     windowsize=pow(2,atoi(argv[1])-1);  
    if(!checkint1(argc,argv)) return 0;
    else if(!checkint2(argc,argv,maxid)) return 0; 
    else if(argc<3)  {cout<<"Invalid initSeq";return 0;}
    else if(!checkrest(argc,argv,maxid)) return 0;
    else{      
        for(int i=3;i<=argc-1;i++)
          {
              if(atoi(argv[i])!=E)
              { if(R.find(atoi(argv[i]))) {D.insert(atoi(argv[i]));}
              else if(w.find(atoi(argv[i]))) {D.insert(atoi(argv[i]));}
         else if(window(atoi(argv[i]),E,maxid,windowsize)){w.insert(atoi(argv[i]));}
         else  {D.insert(atoi(argv[i]));}}             
              else{
              R.insert(atoi(argv[i]));
              E++;
              if(E>maxid)
              {E--;
              E=E%maxid;}
              }
              checkw(E,R,w,maxid);
              }       
          cout<<"R ";
    ret(R);
    cout<<"E "<<E<<" ";
    cout<<"W ";
     reti(argc,E,maxid,w);
      cout<<"D ";
     ret(D);  
        }
       
  
    return 0;

}
