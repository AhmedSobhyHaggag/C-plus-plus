/* 
 * File:   inorderlinkedlist.h
 * Author: ESC
 *
 * Created on April 16, 2015, 10:24 PM
 */

#ifndef INORDERLINKEDLIST_H
#define	INORDERLINKEDLIST_H
typedef int listelemtype;
class inorderlinkedlist {
public:
 inorderlinkedlist();
 bool insert (const listelemtype &e );
 bool first ( listelemtype &e );
 bool next ( listelemtype &e );
 bool find ( listelemtype e );
 void del (const listelemtype &e);
private:struct  node;
typedef node* link;
struct node{
    listelemtype elem;
    link next;
};
link head,current,tail;
};

#endif	/* INORDERLINKEDLIST_H */

