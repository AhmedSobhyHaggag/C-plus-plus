/* 
 * File:   inorderlinkedlist.cpp
 * Author: ESC
 * 
 * Created on April 16, 2015, 10:24 PM
 */
#include <iostream>
#include "inorderlinkedlist.h"
typedef int listelemtype;
inorderlinkedlist::inorderlinkedlist() {
    head=tail=current=NULL;
}
bool inorderlinkedlist::insert(const listelemtype &e )
{
 link addednode,pred=NULL,temp=NULL;
addednode=new node;
if(addednode==NULL) return false;
addednode->elem=e;
if((head==NULL)||(addednode->elem<=head->elem))
{addednode->next=head;
head=addednode;
if(tail==NULL) tail=head;
return true;
}
else{pred=head;
while(((pred->next)!=NULL)&&((pred->next->elem)<(addednode->elem)))
{pred=pred->next;}
temp=pred->next;
pred->next=addednode;
addednode->next=temp;
}
if(addednode->next==NULL)
{tail=addednode;}
return true;
}
bool inorderlinkedlist::first ( listelemtype &e )
 {
     if(head==0)   return false;
     else{current=head;e=current->elem;return true;}
 }
bool inorderlinkedlist::next( listelemtype &e )
{
    if((current==0)||(current->next==NULL))return false;
    else {current=current->next;
    e=current->elem;}
    return true;
}
 bool inorderlinkedlist:: find ( listelemtype e )
 {   listelemtype l;
     bool flag;
     flag=this->first(l);
     while(flag){
         if(l==e) return true;
         flag=this->next(l);
     }
     return false;
 }
 void inorderlinkedlist::del(const listelemtype &e)
{
if(head==NULL)return; // if the list is empty, do nothing
link pred, deleted;
// we will separate the case of deleting the first node, because we will change ‘head’ and because the following while loop starts at the second node
if(head->elem == e)
{
deleted=head;
head=head->next;
if(current==deleted)current=current->next;
delete deleted;
return;
}
// then check the rest of the nodes after head:
pred=head;
while (pred->next != 0)
{
if(pred->next->elem == e)
{
deleted=pred->next;
pred->next=deleted->next; //or pred->next=pred->next->next;
if(current==deleted)current=current->next;
delete deleted;
return; //if we remove this return , we will delete all occurrences of target from the list
}
pred= pred->next;
}
}

