/* 
 * File:   linkedlist.cpp
 * Author: ESC
 * 
 * Created on April 12, 2015, 4:26 PM
 */
#include <iostream>
#include "linkedlist.h"
typedef int listelemtype;
linkedlist::linkedlist() {
  head=tail=current=NULL;
}
 bool linkedlist::insert (const listelemtype &e )
 {
     link addednode;
     addednode=new node;
     if(addednode==NULL) return false;
     addednode->elem=e;
     addednode->next=NULL;
     if(head==NULL){head=tail=addednode;}
     else{tail->next=addednode;
     tail=addednode;}
     return true;
         
 }
 bool linkedlist::first ( listelemtype &e )
 {
     if(head==NULL)   return false;
     else{current=head;e=current->elem;return true;}
 }
bool linkedlist::next( listelemtype &e )
{
    if((current==NULL)||(current->next==NULL))return false;
    else {current=current->next;
    e=current->elem;}
    return true;
}
 bool linkedlist:: find ( listelemtype e )
 {   listelemtype l;
     bool flag;
     flag=this->first(l);
     while(flag){
         if(l==e)return true;
         flag=this->next(l);
     }
     return false;
 }
 void linkedlist::del(const listelemtype &e)
{
if(head==NULL)return; // if the list is empty, do nothing
link pred, deleted;
// we will separate the case of deleting the first node, because we will change ‘head’ and because the following while loop starts at the second node
if(head->elem == e)
{
deleted=head;
head=head->next;
if(current==deleted)current=current->next;
delete deleted;
return;
}
// then check the rest of the nodes after head:
pred=head;
while (pred->next != NULL)
{
if(pred->next->elem == e)
{
deleted=pred->next;
pred->next=deleted->next; //or pred->next=pred->next->next;
if(current==deleted)current=current->next;
delete deleted;
return; //if we remove this return , we will delete all occurrences of target from the list
}
pred= pred->next;
}}
