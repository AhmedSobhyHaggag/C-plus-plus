/* 
 * File:   BST.h
 * Author: ESC
 *
 * Created on May 23, 2015, 10:53 PM
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <math.h>
using namespace std;
#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <math.h>
#include <iomanip> 
#include <assert.h> 

#ifndef BST_H
#define	BST_H
template < class btElementType >
class BST {
public:
    BST();
    bool isEmpty() const;
    btElementType getData() const;
    int getcount() const;
    void insert(const btElementType & d);
    BST < btElementType > * retrieve(const btElementType & d);    
    BST< btElementType >*left();
    BST< btElementType >*right();
    void makeLeft(BST*T1);
    void makeright(BST*T1);
private:
bool nullTree;
btElementType treeData;
int count=1;
BST * leftTree;
BST * rightTree;
};
template < class btElementType >
BST< btElementType > :: BST()
{
nullTree = true;
leftTree = 0;
rightTree = 0;
}
template < class btElementType >
bool
BST < btElementType > :: isEmpty() const
{
return nullTree;
}
template < class btElementType >
btElementType BST < btElementType > :: getData() const
{
if (isEmpty()) return 0;
return treeData;
}
template < class btElementType >
int
BST < btElementType > :: getcount() const
{
if (isEmpty()) return 0;
return count;
}
template < class btElementType >
BST < btElementType >*BST< btElementType > :: left()
{
if (isEmpty()) return 0;
return leftTree;
}
template < class btElementType >
BST < btElementType > *
BST < btElementType > :: right()
{
if (isEmpty()) return 0;
return rightTree;
}
template < class btElementType >
void BST < btElementType >::makeLeft(BST * T1)
{
if (isEmpty()) return 0;
if  (!left()->isEmpty()) return 0;
delete left(); // could be nullTree true, w/data
leftTree = T1;
}
template < class btElementType >
void BST < btElementType >:: makeright(BST * T1)
{
if (isEmpty()) return 0;
if  (!right()->isEmpty()) return 0;
delete right();
rightTree = T1;
}
template < class btElementType >
void BST < btElementType >:: insert(const btElementType & d)
{
if (nullTree) {
nullTree = false;
leftTree = new BST;
rightTree = new BST;
treeData = d;
}
else if (d==treeData)    this->count++ ; // increment count!
else if (d<treeData)
{leftTree->insert(d);}// insert in left subtree
else
{rightTree->insert(d);  } // insert in right subtree
}
template < class btElementType >
BST < btElementType > *BST < btElementType > :: retrieve(const btElementType & d)
{
if (nullTree ||(d==treeData))
// return pointer to tree for which retrieve was called
return this;
else if (d<treeData)
return leftTree->retrieve(d); // recurse left
else
return rightTree->retrieve(d); // recurse right
}
typedef BST < string > btstr;
typedef btstr * btstrp;


#endif	/* BST_H */

