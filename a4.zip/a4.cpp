/* 
 * File:   main.cpp
 * Author: ESC
 *
 * Created on May 23, 2015, 10:11 PM
 */
#include "BST.h"
void preOrderTraverse(btstrp bt)
{ if (!bt->isEmpty()) { // if not empty
// visit tree
cout << bt->getData()<<" "<<bt->getcount() <<" ";
// traverse left child
preOrderTraverse(bt->left());
// traverse right child
preOrderTraverse(bt->right());
}
}
void inOrderTraverse(btstrp bt)
{
if (!bt->isEmpty()) {
// traverse left child
inOrderTraverse(bt->left());
// visit tree
cout << bt->getData()<<" "<<bt->getcount() <<" ";
// traverse right child
inOrderTraverse(bt->right());
}
}
void max(btstrp bt,int & s)
{
if (!bt->isEmpty()) {
// traverse left child
max(bt->left(),s);
max(bt->right(),s);
// visit tree
if(bt->getcount()>=s){s=bt->getcount();}
else ;
// traverse right child

}
}
void printmax(btstrp bt,int & s)
{
if (!bt->isEmpty()) {
// traverse left child
printmax(bt->left(),s);
printmax(bt->right(),s);
// visit tree
if(bt->getcount()==s){cout<<bt->getData()<<" ";}
else ;
// traverse right child

}
}
/*int distTraverse(btstrp bt)
{int count=0;
if (!bt->isEmpty()) {
// traverse left child
distTraverse(bt->left());
// visit tree
return count++;
// traverse right child
inOrderTraverse(bt->right());
}
}*/
void postOrderTraverse(btstrp bt)
{
if (!bt->isEmpty()) {// traverse left child
postOrderTraverse(bt->left());// visit tree
postOrderTraverse(bt->right());// traverse right child
cout << bt->getData()<<" "<<bt->getcount()<<" ";
}
}
int count(btstrp b) 
{ 
    if(b == NULL)
        return 0;
    else 
        if(b->left() == NULL && b->right() == NULL)
            return 1;
        else
            return count(b->left()) + count(b->right());    
}
bool error(int argc, char** argv)
{
    
        
    if(argc<3) {cout<<"Incorrect number of arguments";return 1;}
    else if(!strcmp(argv[2],"countWord")){if(argc<4)  {cout<<"Incorrect number of arguments";return 1;}}
    else if((strcmp(argv[2],"countWord")&&strcmp(argv[2],"wordCount")&&strcmp(argv[2],"distWords")&&strcmp(argv[2],"frequentWord")&&strcmp(argv[2],"printPreorder")&&strcmp(argv[2],"printInorder")&&strcmp(argv[2],"printPostorder")))
    {cout<<"Undefined command";  return 1;}    
    return 0;
}   


#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    if (error(argc,argv)) {return 0;}
    btstrp b(new btstr); 
    ifstream file;  
    file.open(argv[1]);
    if(!file.is_open()) {cout<<"File not found";return 0;}
    string word;
    int i=0;
    while(file >> word)  //insetring words from the file into the BST  b
    {
        for(int j=0;word[j];j++)
        {word[j]=tolower(word[j]);}
    b->insert(word) ;    
    i++;
    }
    if(!strcmp(argv[2],"wordCount"))  
    {cout<<i<<" words";}
    else if(!strcmp(argv[2],"distWords"))
    {cout<<count(b)-1<<" distinct words"; }
    else if(!strcmp(argv[2],"frequentWord"))
    {int s=0;
    max(b,s);
    cout<<"Most frequent word is ";
    printmax(b,s);
   }
       else if(!strcmp(argv[2],"countWord"))
    {cout<<argv[3]<<" is repeated "<<b->retrieve(argv[3])->getcount()<<" times";}
      else if(!strcmp(argv[2],"printPreorder"))
    {preOrderTraverse(b);}
       else if(!strcmp(argv[2],"printPostorder"))
       {postOrderTraverse(b);}
       else if(!strcmp(argv[2],"printInorder"))
    {inOrderTraverse(b);}
 
    return 0;
}

