/* 
 * File:   main.cpp
 * Author: ESC
 *
 * Created on May 6, 2015, 12:47 AM
 */

#include "stack.h"

using namespace std;

void print(double ns)
{
  cout << fixed<<showpoint<< setprecision(2)
   << ns ;
}

int fact(int op1)
{ int res=1;
    for(int j=1;j<=op1;j++)
{
        res=res*j;
}
return res;
}
double operation(double op1 ,char op, double op2)
{
    if(op=='+')    return op1+op2;
    else if(op=='-') return op1-op2;
    else if(op=='x') return op1*op2;
    else if(op=='/') return op1/op2;
    else if(op=='%') return (int)op1%(int)op2;
   
}
bool isnum (char*argv)
{
   if(isdigit(argv[0])||argv[0]=='+'||argv[0]=='-') 
   {   
        if(argv[0]=='+'||argv[0]=='-') { 
         if(strlen(argv)<2) { return 0;}
        else {for(int i=1;i<=strlen(argv)-1;i++)
       {if(!isdigit(argv[i]))  { return 0;}}}}
        else{
       for(int i=1;i<=strlen(argv)-1;i++)
       {if(!isdigit(argv[i]))  {; return 0;}}
         return 1;
        }
   }
   else   return 0;}
   


bool isop (char*argv)
{  
    if(strlen(argv)>1)  { return 0;}
    else if(argv[0]=='+'||argv[0]=='-'||argv[0]=='x'||argv[0]=='/'||argv[0]=='%') {   return 1;}
    else  {  return 0;}
}
bool checkerror(int argc ,char**argv)
{    
    int ob=0,cb=0;
      for(int i=1;i<=argc-1;i++)
    {
       for(int j=0;j<=strlen(argv[i])-1;j++)
       {
       if(argv[i][j]=='(')   ob++;
       else if(argv[i][j]==')') cb++; 
       }
    }  
    if(ob!=cb)  {cout<<"Invalid Expression"; return 1;}
     for(int i=1;i<=argc-1;i++)
    {
       for(int j=0;j<=strlen(argv[i])-1;j++)
       {
       if((!isdigit(argv[i][j]))&&((argv[i][j]!='+')&&(argv[i][j]!='-')&&(argv[i][j]!='x')&&(argv[i][j]!='/')
               &&(argv[i][j]!='%')&&(argv[i][j]!='!')&&(argv[i][j]!='(')&&(argv[i][j]!=')')
              ))
        {cout<<"Invalid Expression"; return 1;}
       }    
    }
    if (argv[argc-1][0]!=')'&&!isnum(argv[argc-1])&&argv[argc-1][0]!='!')   {cout<<"Invalid Expression"; return 1;}
    if (argv[1][0]!='('&&!isnum(argv[1]))   {cout<<"Invalid Expression"; return 1;}
      for(int i=1;i<=argc-1;i++)
    {
    if((argv[i][0]=='(')&&!isnum(argv[i+1])&&argv[i+1][0]!='(')
      {cout<<"Invalid Expression"; return 1;}
    }
    for(int i=1;i<=argc-2;i++)
    {
     if(argv[i][0]==')'&&(isnum(argv[i+1])||(argv[i+1][0]=='('))) {cout<<"Invalid Expression"<<5; return 1;} 
    }  
     for(int i=1;i<=argc-1 ;i++)
    {
       if(!isnum(argv[i])&&strlen(argv[i])>1) {cout<<"Invalid Expression"; return 1;} 
     }    
    
    for(int i=1;i<=argc-2;i++)
    {
       if((isnum(argv[i])&&isnum(argv[i+1]))) {cout<<"Invalid Expression"; return 1;}
    }
      for(int i=1;i<=argc-2;i++)
    {if(isop(argv[i])&&isop(argv[i+1]))
     {cout<<"Invalid Expression"; return 1;}
     }
    for(int i=1;i<=argc-2;i++)
    {
        if(isop(argv[i]))
        {if(argv[i][0]=='+'||argv[i][0]=='-'||argv[i][0]=='/'||argv[i][0]=='x'||argv[i][0]=='%') 
        { if(!isnum(argv[i+1])&&argv[i+1][0]!='('){cout<<"Invalid Expression"; return 1;}}}
       
        
        else if(argv[i][0]=='!')
        {if(!isnum(argv[i-1])&&argv[i-1][0]!=')'){cout<<"Invalid Expression"; return 1;}}
        
    }
    return 0;
}
bool preicheck(char c,char sc)
{
  if(c=='+'&&(sc=='+'||sc=='-'||sc=='x'||sc=='/'||sc=='%')) return 1;
  else if (c=='-'&&(sc=='+'||sc=='-'||sc=='x'||sc=='/'||sc=='%')) return 1;
   else if (c=='x'&&(sc=='x'||sc=='/')) return 1;
   else if (c=='/'&&(sc=='x'||sc=='/'||sc=='%')) return 1;
   else if (c=='%'&&(sc=='x'||sc=='/'||sc=='%')) return 1;
    else return 0;
}
bool checknum(char*argv,Stack<double> &nstack)
{
    
    if(isdigit(argv[0])) {nstack.push((double)atoi(argv))  ; return 1;}
    else if ((argv[0]=='-')&&(isdigit(argv[1]))) { nstack.push((double)atoi(argv))  ; return 1;}
    else if ((argv[0]=='+')&&(isdigit(argv[1]))) { nstack.push((double)atoi(argv))  ; return 1;}   
    else return 0;
    
}

/*
 * 
 */
int main(int argc, char** argv) {
    if(argc<3)  { if(argc==2) print((double)atoi(argv[1]));
    else print(0); 
    return 0;}
     Stack <char> cstack; 
     Stack <double> nstack;   
     double op2,op1;   
     char   op; 
     if (checkerror(argc,argv))  { return 0;}
     for(int i=1;i<=argc-1;i++)
     {
        
     if(argv[i][0]=='(')  {   cstack.push(argv[i][0]);}
     else if(checknum((argv[i]),nstack))  { goto l;}
     else if(argv[i][0]=='+'||argv[i][0]=='-'||argv[i][0]=='/'||argv[i][0]=='x'||argv[i][0]=='%') 
     {l2:if(preicheck(argv[i][0],cstack.top()))
     {   
         op2=nstack.pop();   
         op1=nstack.pop();   
         op=cstack.pop();    
        // if(op=='%'&&op2==0)  {cout<<"Invalid Expression"; return 0;}
         nstack.push(operation(op1,op,op2)); goto l2;
         cstack.push(argv[i][0]);     
     }
         else cstack.push(argv[i][0]);    
     }
       else if(argv[i][0]=='!') 
     {
       
         op1=nstack.pop();  
       if(op1<0)  {  cout<<"Invalid Expression"; return 0;}
         nstack.push((double)fact(op1));   
             //cstack.push(argv[i][0]);   cout<<23<<" ";
     }
     else if(argv[i][0]==')') 
      {
         
         d:if(cstack.top()=='(') {char nd;   nd=cstack.pop();  goto l;  }
         else {op=cstack.pop();   op2=nstack.pop();  op1=nstack.pop(); ; 
         if(op=='%'&&op2==0)  {cout<<"Invalid Expression"; return 0;}
         nstack.push(operation(op1,op,op2));   }
         goto d;  
      }
  
     l:;  }
   {     if(cstack.isEmpty())
       {print(nstack.pop()); }
       else{
          l1: op=cstack.pop();  
           op2=nstack.pop(); 
           op1=nstack.pop();    
           if(op=='%'&&op2==0)  {cout<<"Invalid Expression"; return 0;}
           if(cstack.isEmpty()) {print(operation(op1,op,op2));  }
           else {nstack.push(operation(op1,op,op2)); 
           goto l1; ;}
       }
   }
      
     

    return 0;
}

