#ifndef STACK_H
#define	STACK_H


/* 
 * File:   stack.h
 * Author: ESC
 *
 * Created on May 6, 2015, 12:47 AM
 */
#include "stack.h"
#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <math.h>
using namespace std;
#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <string.h>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <math.h>
#include <iomanip> 
#include <assert.h> 

template < class StackElementType >
class Stack {
public:
Stack();
void push(StackElementType e);
StackElementType pop();
StackElementType top();
bool isEmpty();
private:
struct Node;
typedef Node * Link;
struct Node {
StackElementType data;
Link next;
};
Link head;
};
/* 
 * File:   stack.cpp
 * Author: ESC
 * 
 * Created on May 6, 2015, 12:47 AM
 */


template <class StackElementType>
Stack<StackElementType>::Stack()
{
head = NULL;
}
template < class StackElementType >
void Stack < StackElementType >::push(StackElementType e)
{
Link addedNode = new Node;
if(addedNode==NULL)     return ;
addedNode->data = e;
addedNode->next = head;
head = addedNode;
}
template < class StackElementType >
StackElementType Stack < StackElementType >::pop()
{   if (head==NULL) return 0;
    StackElementType temp1=head->data;
    Link temp2=head;
    head=head->next;
    delete temp2;
    return temp1;
}
template < class StackElementType >
StackElementType Stack < StackElementType >::top()
{
   if (head==NULL) return 0;
    StackElementType temp1=head->data;
    return temp1;
}
template < class StackElementType >
bool Stack < StackElementType >::isEmpty()
{
    return(head==0); 
    
}






#endif	/* STACK_H */

